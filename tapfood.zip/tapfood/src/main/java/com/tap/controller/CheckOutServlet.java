package com.tap.controller;

import com.tapfood.model.cart;
import com.tapfood.model.cartItem;
import com.tapfood.model.user;  // Import the User class

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/checkOut")
public class CheckOutServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve cart from session
        HttpSession session = request.getSession();
        cart cart = (cart) session.getAttribute("cart");

        if (cart == null || cart.getItem().isEmpty()) {
            response.sendRedirect("Home"); // Redirect to home if cart is empty
            return;
        }

        // Retrieve user details from the session (logged-in user)
        user loggedInUser = (user) session.getAttribute("loggedInUser");

        if (loggedInUser == null) {
            response.sendRedirect("login.jsp"); // If no user is logged in, redirect to login page
            return;
        }

        // Get delivery address from the form (since it's specific to the order)
        String address = request.getParameter("address");

        // Calculate the total order amount
        double total = 0;
        for (cartItem item : cart.getItem().values()) {
            total += item.getQuantity() * item.getPrice();
        }

        // Store order details and total amount in session
        session.setAttribute("orderName", loggedInUser.getUsername());
        session.setAttribute("orderEmail", loggedInUser.getEmail());
        session.setAttribute("orderAddress", address);  // Address from the form
        session.setAttribute("orderPhone", loggedInUser.getPhonenumber());
        session.setAttribute("totalAmount", total);

        // Clear the cart after processing the order
        session.removeAttribute("cart");

        // Redirect to the order confirmation page
        response.sendRedirect("orderConfirmation");
    }
}
