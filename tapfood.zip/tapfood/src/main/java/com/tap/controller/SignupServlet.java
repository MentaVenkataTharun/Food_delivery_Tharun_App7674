package com.tap.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/signup")
public class SignupServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/tapfood";
    private static final String JDBC_USERNAME = "root"; 
    private static final String JDBC_PASSWORD = "root"; 
    
    private static final String INSERT_USER_SQL = "INSERT INTO user (username, email, phonenumber, password, address) VALUES (?, ?, ?, ?, ?)";

    // JDBC driver registration
    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); // Ensure you have the MySQL JDBC Driver in your project
            try {
				Connection con=DriverManager.getConnection( JDBC_URL, JDBC_USERNAME, JDBC_PASSWORD);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
        throws ServletException, IOException {
        
        // Retrieve form parameters
        String username = request.getParameter("username");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String phonenumber = request.getParameter("phonenumber");
        String address = request.getParameter("address");
        
        // Register the user
        try {
            registerUser(username, email, phonenumber, password, address);
            // Redirect to login page or success page after successful registration
            response.sendRedirect("login.jsp"); // Ensure the login.jsp exists
        } catch (SQLException e) {
            e.printStackTrace();
            // If registration fails, forward back to the signup page with an error message
            request.setAttribute("errorMessage", "Registration failed! Please try again.");
            request.getRequestDispatcher("signUp.jsp").forward(request, response); // Ensure the file name is correct
        }
    }

    private void registerUser(String username, String email, String phonenumber, String password, String address) 
        throws SQLException {
        // Establish database connection and execute the query
        try (Connection connection = DriverManager.getConnection(JDBC_URL, JDBC_USERNAME, JDBC_PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USER_SQL)) {
            
            // Set the parameters for the SQL query
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, email);
            preparedStatement.setString(3, phonenumber);
            preparedStatement.setString(4, password);
            preparedStatement.setString(5, address);
            
            // Execute the SQL update
            int result = preparedStatement.executeUpdate();

            // Check if the update was successful
            if (result > 0) {
                System.out.println("User registered successfully.");
            } else {
                System.out.println("User registration failed.");
            }
        }
    }
}
