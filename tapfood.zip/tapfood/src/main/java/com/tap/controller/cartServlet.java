package com.tap.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.tapfood.dao.menudao;
import com.tapfood.daoimpl.menudaoimpl;
import com.tapfood.model.cart;
import com.tapfood.model.cartItem;
import com.tapfood.model.menu;


@WebServlet("/cart")
public class cartServlet extends HttpServlet {
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		 HttpSession session=req.getSession();
		  cart cart=(cart)session.getAttribute("cart");
		 if(cart==null)
		 {
			 cart=new cart();
			 session.setAttribute("cart", cart);
		 }
		String action=req.getParameter("action");
		if("add".equals(action))
		{
			addItemTocart(req,cart);
		}
		else if("update".equals(action))
		{
			updateCartItem(req,cart);
		}
		else if("remove".equals(action))
		{
			removeItemFromCart(req,cart);
		}
		System.out.println(cart.getItem());
		
			session.setAttribute("cart", cart);
			resp.sendRedirect("cart.jsp ");
		}


	

	public void addItemTocart(HttpServletRequest req, cart cart) {
	    // Extract the item ID and quantity from the request
	    int itemid = Integer.parseInt(req.getParameter("itemid"));
	    int quantity = Integer.parseInt(req.getParameter("quantity"));

	    // Fetch the menu item using its ID
	    menudao menudao = new menudaoimpl();
	    menu menuitem = menudao.getMenuById(itemid);

	    // If the menu item exists, create a new cartItem and add it to the cart
	    if (menuitem != null) {
	        cartItem item = new cartItem(
	            menuitem.getMenuid(),           // itemid
	            menuitem.getRestaurantid(),     // restaurantid
	            menuitem.getMenuname(),         // name
	            quantity,                       // quantity
	            menuitem.getPrice(),            // price
	            (int)(menuitem.getPrice() * quantity)  // subtotal (price * quantity)
	        );
	        cart.addItem(item);
	    }
	}

		public void removeItemFromCart(HttpServletRequest req, cart cart) {
			
			int itemid=Integer.parseInt(req.getParameter("itemid"));
			cart.removeItem(itemid);
		}
		
		public void updateCartItem(HttpServletRequest req, cart cart) {
		    int itemid = Integer.parseInt(req.getParameter("itemid"));
		    int quantity = Integer.parseInt(req.getParameter("quantity"));
		    if (quantity > 0) {
		        cart.updateItem(itemid, quantity);
		    } else {
		        // Optional: Handle invalid quantity input (e.g., set a minimum quantity or remove the item)
		        cart.removeItem(itemid);
		    }
		}


		
	}

