package com.tap.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.tapfood.daoimpl.Restaurantdaoimpl;
import com.tapfood.model.Restaurant;


@WebServlet("/home")
public class homeServlet extends HttpServlet {
	
       Restaurant restaurantdao;
	private Object restaurantsList;
	private Restaurantdaoimpl RestaurantDao;


	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		RestaurantDao=new Restaurantdaoimpl();
		
		List<Restaurant> restaurantList=RestaurantDao.getAllRestaurants();

		  HttpSession session=req.getSession();
		  session.setAttribute("restaurantsList",restaurantsList);
		  resp.sendRedirect("home.jsp");
		
	}
}
