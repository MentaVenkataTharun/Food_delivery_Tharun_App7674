package com.tap.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.tapfood.dao.userdao;
import com.tapfood.daoimpl.userdaoimpl;
import com.tapfood.model.user;

@WebServlet("/login")
public class loginServlet extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String email = req.getParameter("email");
        String password = req.getParameter("password");

        // Fetch user from database
        userdao userdao = new userdaoimpl();
        user user = userdao.getUser(email);

        if (user != null && password.equals(user.getPassword())) {
            // Store user details in session
            HttpSession session = req.getSession();
            session.setAttribute("loggedInUser", user); // Ensure this attribute is set correctly

            // Redirect to home page after successful login
            resp.sendRedirect("home.jsp");
        } else {
            // Redirect to failure page in case of invalid login
            resp.sendRedirect("failure.jsp");
        }
    }
}
