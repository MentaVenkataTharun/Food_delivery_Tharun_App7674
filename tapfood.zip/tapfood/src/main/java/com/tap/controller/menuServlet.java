package com.tap.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.tapfood.dao.menudao;
import com.tapfood.daoimpl.menudaoimpl;
import com.tapfood.model.menu;

@WebServlet("/menu")
public class menuServlet extends HttpServlet {
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		 int restaurantid=Integer.parseInt(req.getParameter("restaurantid"));
	     System.out.println(restaurantid);
	     menudao menudao= new menudaoimpl();
	   ArrayList<menu> menu = menudao.getMenusByRestaurantId(restaurantid);
	    if(menu!=null)
	    {
	    	HttpSession session= req.getSession();
	    	session.setAttribute("menulist", menu);
	    	resp.sendRedirect("menu.jsp");
	    }
	}
}
