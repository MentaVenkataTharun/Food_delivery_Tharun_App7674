package com.tap.controller;

import com.tapfood.daoimpl.orderhistorydaoimpl;
import com.tapfood.daoimpl.orderitemdaoimpl;
import com.tapfood.daoimpl.ordertabledaoimpl;
import com.tapfood.model.cart;
import com.tapfood.model.cartItem;
import com.tapfood.model.orderhistory;
import com.tapfood.model.orderitem;
import com.tapfood.model.ordertable;
import com.tapfood.model.user;

import java.io.IOException;
import java.sql.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/orderConfirmation")
public class orderConfirmation extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Retrieve request parameters with null checks
        String address = req.getParameter("address");
        String paymentMode = req.getParameter("paymentMode");

        // Retrieve the total parameter and check for invalid cases
        String totalStr = req.getParameter("total");
        double totalAmount = 0;

        try {
            if (totalStr != null && !totalStr.isEmpty()) {
                totalAmount = Double.parseDouble(totalStr);  // Parse the total to a double
            } else {
                resp.sendRedirect("error.jsp?error=invalid_total");
                return;  // Stop further processing if total is invalid
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
            resp.sendRedirect("error.jsp?error=invalid_total_format");
            return;
        }

        // Retrieve session attributes
        HttpSession session = req.getSession(false); // Pass false to not create a new session
        cart cart = (session != null) ? (cart) session.getAttribute("cart") : null;
        user user = (session != null) ? (user) session.getAttribute("loggedInUser") : null;
        Integer restaurantid = (session != null) ? (Integer) session.getAttribute("restaurantid") : null;

        // Check if session attributes are valid
        if (cart == null || user == null || restaurantid == null) {
            System.out.println("Session attributes are missing or expired.");
            resp.sendRedirect("error.jsp?error=session_expired"); // Redirect to error page for session expiry
            return;
        }

        // Create a new ordertable object
        ordertable orderDetails = new ordertable(
            0, 
            user.getUserid(),
            restaurantid,
            new Date(System.currentTimeMillis()), 
            totalAmount,  // Corrected total amount
            paymentMode, 
            "Pending"
        );

        ordertabledaoimpl orderDetailsDao = new ordertabledaoimpl();
        orderitemdaoimpl orderItemDao = new orderitemdaoimpl();
        orderhistorydaoimpl orderHistoryDao = new orderhistorydaoimpl();

        int status = 0;

        try {
            // Add order details to the database
            status = orderDetailsDao.addOrder(orderDetails);
            if (status == 1) {
                // Fetch the newly inserted order details
                orderDetails = orderDetailsDao.getSpecificOrder();
                int orderid = orderDetails.getOrderid();

                // Insert each cart item as an order item
                for (cartItem cartItem : cart.getItem().values()) {
                    int menuid = cartItem.getItemid();
                    int quantity = cartItem.getQuantity();
                    double subtotal = cartItem.getSubtotal();

                    orderitem orderItem = new orderitem();
                    orderItem.setOrderid(orderid);
                    orderItem.setMenuid(menuid);
                    orderItem.setQuantity(quantity);
                    orderItem.setSubtotal(subtotal);

                    orderItemDao.addOrderItem(orderItem);
                }

                // Add the order to order history
                orderhistory orderHistory = new orderhistory();
                orderHistory.setOrderid(orderid);
                orderHistory.setTotalamount(totalAmount);
                orderHistory.setUserid(user.getUserid());

                orderHistoryDao.addOrderHistory(orderHistory);
            } else {
                // Redirect to error page if order insertion fails
                resp.sendRedirect("error.jsp?error=order_failed");
                return;
            }
        } catch (Exception e) {
            e.printStackTrace();
            resp.sendRedirect("error.jsp?error=exception");
            return;
        } finally {
            // Clear the cart after processing is done, regardless of success or failure
            if (cart != null) {
                cart.clear();
                System.out.println("Cart cleared.");
            }

            // Redirect to order confirmation page if order placement is successful
            if (status == 1) {
                resp.sendRedirect("orderConfirmation.jsp");
            }
        }
    }
}