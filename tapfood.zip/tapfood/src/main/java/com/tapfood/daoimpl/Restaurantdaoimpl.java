package com.tapfood.daoimpl;

import java.util.List;
import com.tapfood.dao.RestaurantDao;
import com.tapfood.dbutils.dbutils;
import com.tapfood.model.Restaurant;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Restaurantdaoimpl implements RestaurantDao {

    private Connection con;
    private PreparedStatement pstmt;
    private static final String ADD_RESTAURANT = "INSERT INTO restaurant (restaurantname, deliverytime, cuisinetype, rating, address, isactive, adminid, image) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    private static final String SELECT_ALL = "SELECT * FROM restaurant";
    private static final String SELECT_BY_ID = "SELECT * FROM restaurant WHERE restaurantid = ?";
    private static final String UPDATE_BY_ID = "UPDATE restaurant SET restaurantname = ?, deliverytime = ?, cuisinetype = ?, rating = ?, address = ?, isactive = ?, adminid = ?, image = ? WHERE restaurantid = ?";
    private static final String DELETE_BY_ID = "DELETE FROM restaurant WHERE restaurantid = ?";

    public Restaurantdaoimpl() {
        try {
            con = dbutils.myConnect(); // Assuming DBUtils handles database connection
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public int addRestaurant(Restaurant restaurant) {
        int status = 0;
        try {
            pstmt = con.prepareStatement(ADD_RESTAURANT);
            pstmt.setString(1, restaurant.getRestaurantname());
            pstmt.setInt(2, restaurant.getDeliverytime());
            pstmt.setString(3, restaurant.getCuisinetype());
            pstmt.setDouble(4, restaurant.getRating());
            pstmt.setString(5, restaurant.getAddress());
            pstmt.setString(6, restaurant.getIsactive());
            pstmt.setInt(7, restaurant.getAdminid());
            pstmt.setString(8, restaurant.getImage());
            status = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources();
        }
        return status;
    }

    @Override
    public List<Restaurant> getAllRestaurants() {
        List<Restaurant> restaurantList = new ArrayList<>();
        try (PreparedStatement pstmt = con.prepareStatement(SELECT_ALL);
             ResultSet resultSet = pstmt.executeQuery()) {
            restaurantList = extractRestaurantFromResultSet(resultSet);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return restaurantList;
    }

    @Override
    public Restaurant getRestaurant(int restaurantid) {
        Restaurant restaurant = null;
        try {
            pstmt = con.prepareStatement(SELECT_BY_ID);
            pstmt.setInt(1, restaurantid);
            ResultSet resultSet = pstmt.executeQuery();
            List<Restaurant> resultList = extractRestaurantFromResultSet(resultSet);
            if (!resultList.isEmpty()) {
                restaurant = resultList.get(0);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources();
        }
        return restaurant;
    }

    @Override
    public int updateRestaurant(Restaurant restaurant) {
        int status = 0;
        try {
            pstmt = con.prepareStatement(UPDATE_BY_ID);
            pstmt.setString(1, restaurant.getRestaurantname());
            pstmt.setInt(2, restaurant.getDeliverytime());
            pstmt.setString(3, restaurant.getCuisinetype());
            pstmt.setDouble(4, restaurant.getRating());
            pstmt.setString(5, restaurant.getAddress());
            pstmt.setString(6, restaurant.getIsactive());
            pstmt.setInt(7, restaurant.getAdminid());
            pstmt.setString(8, restaurant.getImage());
            pstmt.setInt(9, restaurant.getRestaurantid()); // Ensure the restaurantid is passed correctly
            status = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources();
        }
        return status;
    }

    @Override
    public int deleteRestaurant(int restaurantid) {
        int status = 0;
        try {
            pstmt = con.prepareStatement(DELETE_BY_ID);
            pstmt.setInt(1, restaurantid);
            status = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources();
        }
        return status;
    }

    private List<Restaurant> extractRestaurantFromResultSet(ResultSet resultSet) {
        List<Restaurant> restaurants = new ArrayList<>();
        try {
            while (resultSet.next()) {
                restaurants.add(new Restaurant(
                    resultSet.getInt("restaurantid"),
                    resultSet.getInt("deliverytime"),
                    resultSet.getInt("adminid"),
                    resultSet.getString("restaurantname"),
                    resultSet.getString("cuisinetype"),
                    resultSet.getString("address"),
                    resultSet.getString("image"),
                    resultSet.getFloat("rating"),
                    resultSet.getString("isactive")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return restaurants;
    }

    private void closeResources() {
        try {
            if (pstmt != null) {
                pstmt.close();
            }
            if (con != null) {
                con.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
