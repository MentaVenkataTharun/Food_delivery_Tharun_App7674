package com.tapfood.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.tapfood.dao.menudao;
import com.tapfood.dbutils.dbutils;
import com.tapfood.model.menu;

public class menudaoimpl implements menudao {

    private Connection con;
    private PreparedStatement pstmt;
    private Statement stmt;
    private ResultSet resultSet;

    private static final String ADD_MENU = "INSERT INTO menu (restaurantid, menuname, description, price, isAvailable, imgpath) VALUES (?, ?, ?, ?, ?, ?)";
    private static final String SELECT_ALL = "SELECT * FROM menu";
    private static final String SELECT_BY_ID = "SELECT * FROM menu WHERE menuid = ?";
    private static final String SELECT_BY_RESTAURANT_ID = "SELECT * FROM menu WHERE restaurantid = ?";
    private static final String UPDATE_MENU = "UPDATE menu SET restaurantid = ?, menuname = ?, description = ?, price = ?, isAvailable = ?, imgpath = ? WHERE menuid = ?";
    private static final String DELETE_MENU = "DELETE FROM menu WHERE menuid = ?";

    public menudaoimpl() {
        try {
            con = dbutils.myConnect();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public int addMenu(menu m) {
        int status = 0;
        try {
            pstmt = con.prepareStatement(ADD_MENU);
            pstmt.setInt(1, m.getRestaurantid());
            pstmt.setString(2, m.getMenuname());
            pstmt.setString(3, m.getDescription());
            pstmt.setDouble(4, m.getPrice());
            pstmt.setBoolean(5, m.isAvailable());
            pstmt.setString(6, m.getImgpath());
            status = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return status;
    }

    @Override
    public ArrayList<menu> getAllMenus() {
        ArrayList<menu> menuList = new ArrayList<>();
        try {
            stmt = con.createStatement();
            resultSet = stmt.executeQuery(SELECT_ALL);
            menuList = extractMenusFromResultSet(resultSet);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return menuList;
    }

    @Override
    public ArrayList<menu> getMenusByRestaurantId(int restaurantid) {
        ArrayList<menu> menuList = new ArrayList<>();
        try {
            pstmt = con.prepareStatement(SELECT_BY_RESTAURANT_ID);
            pstmt.setInt(1, restaurantid);
            resultSet = pstmt.executeQuery();
            menuList = extractMenusFromResultSet(resultSet);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return menuList;
    }

    @Override
    public menu getMenuById(int menuid) {
        menu m = null;
        try {
            pstmt = con.prepareStatement(SELECT_BY_ID);
            pstmt.setInt(1, menuid);
            resultSet = pstmt.executeQuery();
            ArrayList<menu> menuList = extractMenusFromResultSet(resultSet);
            if (!menuList.isEmpty()) {
                m = menuList.get(0);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return m;
    }

    @Override
    public int updateMenu(menu m) {
        int status = 0;
        try {
            pstmt = con.prepareStatement(UPDATE_MENU);
            pstmt.setInt(1, m.getRestaurantid());
            pstmt.setString(2, m.getMenuname());
            pstmt.setString(3, m.getDescription());
            pstmt.setDouble(4, m.getPrice());
            pstmt.setBoolean(5, m.isAvailable());
            pstmt.setString(6, m.getImgpath());
            pstmt.setInt(7, m.getMenuid());
            status = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return status;
    }

    @Override
    public int deleteMenu(int menuid) {
        int status = 0;
        try {
            pstmt = con.prepareStatement(DELETE_MENU);
            pstmt.setInt(1, menuid);
            status = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return status;
    }

    private ArrayList<menu> extractMenusFromResultSet(ResultSet resultSet) {
        ArrayList<menu> menuList = new ArrayList<>();
        try {
            while (resultSet.next()) {
                menu m = new menu(
                    resultSet.getInt("menuid"),
                    resultSet.getInt("restaurantid"),
                    resultSet.getString("menuname"),
                    resultSet.getString("description"),
                    resultSet.getDouble("price"),
                    resultSet.getBoolean("isAvailable"),
                    resultSet.getString("imgpath")
                );
                menuList.add(m);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return menuList;
    }
}
