package com.tapfood.daoimpl;

import com.tapfood.dao.orderhistorydao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


import com.tapfood.dbutils.dbutils;
import com.tapfood.model.orderhistory;

public class orderhistorydaoimpl implements orderhistorydao{

	 Connection con;
	    private PreparedStatement pstmt;
	    private Statement stmt;
	    private ResultSet resultSet;
	    ArrayList<orderhistory> orderHistoryList = new ArrayList<>();
	    orderhistory oh;

	    private static final String ADD_ORDER_HISTORY = "INSERT INTO orderhistory (orderid, userid, orderdate, totalamount, status) VALUES (?, ?, ?, ?, ?)";
	    private static final String SELECT_ALL = "SELECT * FROM orderhistory";
	    private static final String SELECT_BY_ID = "SELECT * FROM orderhistory WHERE orderhistoryid = ?";
	    private static final String SELECT_BY_USER_ID = "SELECT * FROM orderhistory WHERE userid = ?";
	    private static final String UPDATE_ORDER_HISTORY = "UPDATE orderhistory SET orderid = ?, userid = ?, orderdate = ?, totalamount = ?, status = ? WHERE orderhistoryid = ?";
	    private static final String DELETE_ORDER_HISTORY = "DELETE FROM orderhistory WHERE orderhistoryid = ?";

	    public orderhistorydaoimpl() {
	        try {
	            con = dbutils.myConnect();
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }

	    @Override
	    public int addOrderHistory(orderhistory oh) {
	        int status = 0;
	        try {
	            pstmt = con.prepareStatement(ADD_ORDER_HISTORY);
	            pstmt.setInt(1, oh.getOrderid());
	            pstmt.setInt(2, oh.getUserid());
	            pstmt.setDate(3, oh.getOrderdate());
	            pstmt.setDouble(4, oh.getTotalamount());
	            pstmt.setString(5, oh.getStatus());
	            status = pstmt.executeUpdate();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return status;
	    }

	    @Override
	    public ArrayList<orderhistory> getAllOrderHistories() {
	        try {
	            stmt = con.createStatement();
	            resultSet = stmt.executeQuery(SELECT_ALL);
	            orderHistoryList = extractOrderHistoriesFromResultSet(resultSet);
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return orderHistoryList;
	    }

	    @Override
	    public orderhistory getOrderHistoryById(int orderHistoryId) {
	        try {
	            pstmt = con.prepareStatement(SELECT_BY_ID);
	            pstmt.setInt(1, orderHistoryId);
	            resultSet = pstmt.executeQuery();
	            orderHistoryList = extractOrderHistoriesFromResultSet(resultSet);
	            if (!orderHistoryList.isEmpty()) {
	                oh = orderHistoryList.get(0);
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return oh;
	    }

	    @Override
	    public ArrayList<orderhistory> getOrderHistoriesByUserId(int userId) {
	        try {
	            pstmt = con.prepareStatement(SELECT_BY_USER_ID);
	            pstmt.setInt(1, userId);
	            resultSet = pstmt.executeQuery();
	            orderHistoryList = extractOrderHistoriesFromResultSet(resultSet);
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return orderHistoryList;
	    }

	    @Override
	    public int updateOrderHistory(orderhistory oh) {
	        int status = 0;
	        try {
	            pstmt = con.prepareStatement(UPDATE_ORDER_HISTORY);
	            pstmt.setInt(1, oh.getOrderid());
	            pstmt.setInt(2, oh.getUserid());
	            pstmt.setDate(3, oh.getOrderdate());
	            pstmt.setDouble(4, oh.getTotalamount());
	            pstmt.setString(5, oh.getStatus());
	            pstmt.setInt(6, oh.getOrderhistoryid());
	            status = pstmt.executeUpdate();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return status;
	    }

	    @Override
	    public int deleteOrderHistory(int orderHistoryId) {
	        int status = 0;
	        try {
	            pstmt = con.prepareStatement(DELETE_ORDER_HISTORY);
	            pstmt.setInt(1, orderHistoryId);
	            status = pstmt.executeUpdate();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return status;
	    }

	    private ArrayList<orderhistory> extractOrderHistoriesFromResultSet(ResultSet resultSet) {
	        ArrayList<orderhistory> orderHistoryList = new ArrayList<>();
	        try {
	            while (resultSet.next()) {
	                orderhistory oh = new orderhistory(
	                    resultSet.getInt("orderhistoryid"),
	                    resultSet.getInt("orderid"),
	                    resultSet.getInt("userid"),
	                    resultSet.getDate("orderdate"),
	                    resultSet.getFloat("totalamount"),
	                    resultSet.getString("status")
	                );
	                orderHistoryList.add(oh);
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return orderHistoryList;
	    }
}