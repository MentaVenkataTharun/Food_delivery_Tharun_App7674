package com.tapfood.daoimpl;

import java.util.ArrayList;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


import com.tapfood.dao.orderitemdao;
import com.tapfood.dbutils.dbutils;
import com.tapfood.model.orderitem;

public class orderitemdaoimpl implements orderitemdao {

	  Connection con;
	    private PreparedStatement pstmt;
	    private Statement stmt;
	    private ResultSet resultSet;
	    ArrayList<orderitem> orderItemList = new ArrayList<>();
	    orderitem orderItem;
	    
	    private static final String ADD_ORDER_ITEM = "INSERT INTO orderitem (orderid, menuid, quantity, subtotal) VALUES (?, ?, ?, ?)";
	    private static final String SELECT_ALL = "SELECT * FROM orderitem";
	    private static final String SELECT_BY_ID = "SELECT * FROM orderitem WHERE orderitenid = ?";
	    private static final String UPDATE_ORDER_ITEM = "UPDATE orderitem SET orderid = ?, menuid = ?, quantity = ?, subtotal = ? WHERE orderitenid = ?";
	    private static final String DELETE_ORDER_ITEM = "DELETE FROM orderitem WHERE orderitenid = ?";
	    
	    public orderitemdaoimpl() {
	        try {
	            con = dbutils.myConnect();
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
	    
	    @Override
	    public int addOrderItem(orderitem orderItem) {
	        int status = 0;
	        try {
	            pstmt = con.prepareStatement(ADD_ORDER_ITEM);
	            pstmt.setInt(1, orderItem.getOrderid());
	            pstmt.setInt(2, orderItem.getMenuid());
	            pstmt.setInt(3, orderItem.getQuantity());
	            pstmt.setDouble(4, orderItem.getSubtotal());
	            status = pstmt.executeUpdate();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return status;
	    }

	    @Override
	    public ArrayList<orderitem> getAllOrderItems() {
	        try {
	            stmt = con.createStatement();
	            resultSet = stmt.executeQuery(SELECT_ALL);
	            orderItemList = extractOrderItemsFromResultSet(resultSet);
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        return orderItemList;
	    }

	    @Override
	    public orderitem getOrderItemById(int orderItemId) {
	        try {
	            pstmt = con.prepareStatement(SELECT_BY_ID);
	            pstmt.setInt(1, orderItemId);
	            resultSet = pstmt.executeQuery();
	            orderItemList = extractOrderItemsFromResultSet(resultSet);
	            orderItem = orderItemList.get(0);
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        return orderItem;
	    }

	    @Override
	    public int updateOrderItem(orderitem orderItem) {
	        int status = 0;
	        try {
	            pstmt = con.prepareStatement(UPDATE_ORDER_ITEM);
	            pstmt.setInt(1, orderItem.getOrderid());
	            pstmt.setInt(2, orderItem.getMenuid());
	            pstmt.setInt(3, orderItem.getQuantity());
	            pstmt.setDouble(4, orderItem.getSubtotal());
	            pstmt.setInt(5, orderItem.getOrderitenid());
	            status = pstmt.executeUpdate();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return status;
	    }

	    @Override
	    public int deleteOrderItem(int orderItemId) {
	        int status = 0;
	        try {
	            pstmt = con.prepareStatement(DELETE_ORDER_ITEM);
	            pstmt.setInt(1, orderItemId);
	            status = pstmt.executeUpdate();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return status;
	    }
	    
	    private ArrayList<orderitem> extractOrderItemsFromResultSet(ResultSet resultSet) {
	        ArrayList<orderitem> orderItemList = new ArrayList<>();
	        try {
	            while (resultSet.next()) {
	                orderitem orderItem = new orderitem(
	                    resultSet.getInt("orderitenid"),
	                    resultSet.getInt("orderid"),
	                    resultSet.getInt("menuid"),
	                    resultSet.getInt("quantity"),
	                    resultSet.getDouble("subtotal")
	                );
	                orderItemList.add(orderItem);
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return orderItemList;
	    }
}
