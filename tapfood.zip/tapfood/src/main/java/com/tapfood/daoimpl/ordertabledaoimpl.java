package com.tapfood.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.tapfood.dao.ordertabledao;
import com.tapfood.dbutils.dbutils;
import com.tapfood.model.ordertable;

public class ordertabledaoimpl implements ordertabledao{
	
	 private Connection con;
	    private PreparedStatement pstmt;
	    private Statement stmt;
	    private ResultSet resultSet;
	    private ArrayList<ordertable> orderList = new ArrayList<>();
	    private ordertable order;

	    private static final String ADD_ORDER = "INSERT INTO ordertable (userid, restaruantid, orderdate, totalamount, status, paymentmode) VALUES (?, ?, ?, ?, ?, ?)";
	    private static final String SELECT_ALL_ORDERS = "SELECT * FROM ordertable";
	    private static final String SELECT_ORDER_BY_ID = "SELECT * FROM ordertable WHERE orderid = ?";
	    private static final String UPDATE_ORDER = "UPDATE ordertable SET userid = ?, restaruantid = ?, orderdate = ?, totalamount = ?, status = ?, paymentmode = ? WHERE orderid = ?";
	    private static final String DELETE_ORDER = "DELETE FROM ordertable WHERE orderid = ?";

	    public ordertabledaoimpl() {
	        try {
	            con = dbutils.myConnect();
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }

	    @Override
	    public int addOrder(ordertable order) {
	        int status = 0;
	        try {
	            pstmt = con.prepareStatement(ADD_ORDER);
	            pstmt.setInt(1, order.getUserid());
	            pstmt.setInt(2, order.getRestaurantid());
	            pstmt.setDate(3, new java.sql.Date(order.getOrderdate().getTime()));
	            pstmt.setDouble(4, order.getTotalamount());
	            pstmt.setString(5, order.getStatus());
	            pstmt.setString(6, order.getPaymentmode());

	            status = pstmt.executeUpdate();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return status;
	    }

	    @Override
	    public ArrayList<ordertable> getAllOrders() {
	        try {
	            stmt = con.createStatement();
	            resultSet = stmt.executeQuery(SELECT_ALL_ORDERS);
	            orderList = extractOrdersFromResultSet(resultSet);
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return orderList;
	    }

	    @Override
	    public ordertable getOrderById(int orderId) {
	        try {
	            pstmt = con.prepareStatement(SELECT_ORDER_BY_ID);
	            pstmt.setInt(1, orderId);
	            resultSet = pstmt.executeQuery();
	            orderList = extractOrdersFromResultSet(resultSet);
	            if (!orderList.isEmpty()) {
	                order = orderList.get(0);
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return order;
	    }

	    @Override
	    public int updateOrder(ordertable order) {
	        int status = 0;
	        try {
	            pstmt = con.prepareStatement(UPDATE_ORDER);
	            pstmt.setInt(1, order.getUserid());
	            pstmt.setInt(2, order.getRestaurantid());
	            pstmt.setDate(3, new java.sql.Date(order.getOrderdate().getTime()));
	            pstmt.setDouble(4, order.getTotalamount());
	            pstmt.setString(5, order.getStatus());
	            pstmt.setString(6, order.getPaymentmode());
	            pstmt.setInt(7, order.getOrderid());

	            status = pstmt.executeUpdate();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return status;
	    }

	    @Override
	    public int deleteOrder(int orderId) {
	        int status = 0;
	        try {
	            pstmt = con.prepareStatement(DELETE_ORDER);
	            pstmt.setInt(1, orderId);

	            status = pstmt.executeUpdate();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return status;
	    }

	    private ArrayList<ordertable> extractOrdersFromResultSet(ResultSet resultSet) {
	        ArrayList<ordertable> orderList = new ArrayList<>();
	        try {
	            while (resultSet.next()) {
	                ordertable order = new ordertable(
	                    resultSet.getInt("orderid"),
	                    resultSet.getInt("userid"),
	                    resultSet.getInt("restaruantid"),
	                    resultSet.getDate("orderdate"),
	                    resultSet.getDouble("totalamount"),
	                    resultSet.getString("status"),
	                    resultSet.getString("paymentmode")
	                );
	                orderList.add(order);
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return orderList;
	    }




@Override
    public ordertable getSpecificOrder() {
    ordertable order = null;
    String SELECT_LAST_ORDER = "SELECT * FROM ordertable ORDER BY orderid DESC LIMIT 1";

    try {
        stmt = con.createStatement();
        resultSet = stmt.executeQuery(SELECT_LAST_ORDER);
        if (resultSet.next()) {
            // Creating order object using the data from the result set
            order = new ordertable(
                resultSet.getInt("orderid"),
                resultSet.getInt("restaruantid"),
                resultSet.getInt("userid"),
                resultSet.getDate("orderdate"), // Retrieving the date as java.sql.Date
                resultSet.getDouble("total"),
                resultSet.getString("status"),
                resultSet.getString("paymentmode")
            );
        }
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        // Clean up resources (ResultSet, Statement)
        try {
            if (resultSet != null) resultSet.close();
            if (stmt != null) stmt.close();
            if (pstmt != null) pstmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    return order;
}
}
