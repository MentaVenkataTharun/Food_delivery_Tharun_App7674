package com.tapfood.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.tapfood.dao.userdao;
import com.tapfood.dbutils.dbutils;
import com.tapfood.model.user;

public class userdaoimpl implements userdao {
	Connection con;
	private PreparedStatement pstmt;
	private Statement stmt;
	private ResultSet resultSet;
	ArrayList<user> userList=new ArrayList<user>();
	user user;
	
	private static final String ADD_USER="insert into 'user'(`username`,`email`,`phonenumber`,`password`,`address`)values(?,?,?,?,?)";
	private static final String SELECT_ALL="select * from 'user'";
	private static final String SELECT_ON_EMAIL="select * from user where email=?";
	private static final String UPDATE_ON_EMAIL="update`user` set `username`=?,`phonenumber`=?,`password`=?,`address`=? where `email`=? ";
	private static final String DELETE_ON_EMAIL="delete from 'user' where email=? ";
	int status=0;
	
	public userdaoimpl() {
		
		try {
		con=dbutils.myConnect();
		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	@Override
	 public int addUser(user u) {
        try {
            pstmt = con.prepareStatement(ADD_USER);
            pstmt.setString(1, u.getUsername());
            pstmt.setString(2, u.getEmail());
            pstmt.setString(3, u.getPhonenumber());
            pstmt.setString(4, u.getPassword());
            pstmt.setString(5, u.getAddress());

            status = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return status;
    }
@Override
	public ArrayList<user> getAllUsers() {
         try {
        	 stmt=con.createStatement();
        	 resultSet=stmt.executeQuery(SELECT_ALL);
        	 userList=extractUserFromResultSet(resultSet) ;
        	
        		 
        	 
         }
         catch(Exception e) {
        	 e.printStackTrace();
         }
         return userList;
		
	}
@Override
	public user getUser(String email) {
		  try {
	        	 
			  pstmt=con.prepareStatement(SELECT_ON_EMAIL);
			  pstmt.setString(1, email);
			 resultSet= pstmt.executeQuery();
			 userList=extractUserFromResultSet(resultSet);
			 user=userList.get(0);
	         }
	         catch(Exception e) {
	        	 e.printStackTrace();
	         }
		  return user;
				
	}
	@Override
	public int updateUser(user u) {
		  try {
			  pstmt=con.prepareStatement(UPDATE_ON_EMAIL);
			  pstmt.setString(1, u.getUsername());
			  pstmt.setString(2,u.getPhonenumber());
			  pstmt.setString(3,u.getPassword());
			  pstmt.setString(4,u.getAddress());
			  pstmt.setString(5, u.getEmail());
			  
			  status=pstmt.executeUpdate();
	         }
	         catch(Exception e) {
	        	 e.printStackTrace();
	         }
		   return status;
			
		
	}
	@Override
	public int deleteUser(String email) {
		  try {
	        	 pstmt=con.prepareStatement(DELETE_ON_EMAIL);
	        	 pstmt.setString(1,email);
	        	 
	        	 status=pstmt.executeUpdate();
	        	 
	         }
	         catch(Exception e) {
	        	 e.printStackTrace();
	         }
			return status;
		
	}
	
	ArrayList<user> extractUserFromResultSet(ResultSet resultSet) {
		try {
			 while(resultSet.next()) {
	        		userList.add( new user(resultSet.getInt("userid"),
	               		 resultSet.getString("username"),
	            		 resultSet.getString("email"),
	            		 resultSet.getString("phonenumber"),
	            		 resultSet.getString("password"),
	            		 resultSet.getString("address")));
		}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return userList;
	}

}
