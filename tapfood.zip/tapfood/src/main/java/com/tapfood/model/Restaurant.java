package com.tapfood.model;

public class Restaurant {
    private int restaurantid, deliverytime, adminid;
    private String restaurantname, cuisinetype, address, image, isactive;
    private float rating;

    public Restaurant() {
        super();
    }

    public Restaurant(int restaurantid, int deliverytime, int adminid, String restaurantname, String cuisinetype,
                     String address, String image, float rating, String isactive) {
        this.restaurantid = restaurantid;
        this.deliverytime = deliverytime;
        this.adminid = adminid;
        this.restaurantname = restaurantname;
        this.cuisinetype = cuisinetype;
        this.address = address;
        this.image = image;
        this.rating = rating;
        this.isactive = isactive;
    }

    public Restaurant(int deliverytime, int adminid, String restaurantname, String cuisinetype, String address,
                     String image, float rating, String isactive) {
        this.deliverytime = deliverytime;
        this.adminid = adminid;
        this.restaurantname = restaurantname;
        this.cuisinetype = cuisinetype;
        this.address = address;
        this.image = image;
        this.rating = rating;
        this.isactive = isactive;
    }

    // Getters and Setters
    public int getRestaurantid() {
        return restaurantid;
    }

    public void setRestaurantid(int restaurantid) {
        this.restaurantid = restaurantid;
    }

    public int getDeliverytime() {
        return deliverytime;
    }

    public void setDeliverytime(int deliverytime) {
        this.deliverytime = deliverytime;
    }

    public int getAdminid() {
        return adminid;
    }

    public void setAdminid(int adminid) {
        this.adminid = adminid;
    }

    public String getRestaurantname() {
        return restaurantname;
    }

    public void setRestaurantname(String restaurantname) {
        this.restaurantname = restaurantname;
    }

    public String getCuisinetype() {
        return cuisinetype;
    }

    public void setCuisinetype(String cuisinetype) {
        this.cuisinetype = cuisinetype;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public float getRating() {
        return rating;
    }

    public void setRating(float rating) {
        this.rating = rating;
    }

    public String getIsactive() {
        return isactive;
    }

    public void setIsactive(String isactive) {
        this.isactive = isactive;
    }

    @Override
    public String toString() {
        return "Restaurant [restaurantid=" + restaurantid + ", deliverytime=" + deliverytime + ", adminid=" + adminid
                + ", restaurantname=" + restaurantname + ", cuisinetype=" + cuisinetype + ", address=" + address
                + ", image=" + image + ", rating=" + rating + ", isactive=" + isactive + "]";
    }
}
