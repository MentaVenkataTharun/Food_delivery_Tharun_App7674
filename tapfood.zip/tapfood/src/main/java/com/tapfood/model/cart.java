package com.tapfood.model;

import java.util.HashMap;
import java.util.Map;

public class cart {
	 private Map<Integer,cartItem> items=new HashMap<Integer,cartItem>();
	   //adding items
	   public void addItem(cartItem item)
	   {
		   int itemid=item.getItemid();
		   if(items.containsKey(itemid))
		   {
			   cartItem existingItem=items.get(itemid);
			   existingItem.setQuantity(existingItem.getQuantity()+ item.getQuantity());
		   }
		   else {
			   items.put(itemid, item);
		   }
	   }
	   
	   //Update the quantity of an item in the cart
	   public void updateItem(int itemid, int quantity) {
		    if (items.containsKey(itemid)) {
		        if (quantity <= 0) {
		            items.remove(itemid);
		        } else {
		            cartItem existingItem = items.get(itemid);
		            existingItem.setQuantity(quantity);
		            existingItem.setSubtotal(quantity * existingItem.getPrice()); // Update subtotal as well
		        }
		    }
		}

	   
	  //remove an item from the cart
	   public void removeItem(int itemid)
	   {
		   items.remove(itemid);
	   }
	   public Map<Integer,cartItem> getItem()
	   {
		   return items;
	   }
	   public void clear()
	   {
		   items.clear();
	   }
	   
	   // 
	   
	}


