package com.tapfood.model;

public class menu {
   private int menuid;
   private int restaurantid;
   private String menuname;
   private String description;
   private double price;
   private boolean isAvailable;
   private String imgpath;
public menu() {
	super();
}
public menu(int menuid, int restaurantid, String menuname, String description, double price, boolean isAvailable,
		String imgpath) {
	super();
	this.menuid = menuid;
	this.restaurantid = restaurantid;
	this.menuname = menuname;
	this.description = description;
	this.price = price;
	this.isAvailable = isAvailable;
	this.imgpath = imgpath;
}
public menu(int restaurantid, String menuname, String description, double price, boolean isAvailable, String imgpath) {
	super();
	this.restaurantid = restaurantid;
	this.menuname = menuname;
	this.description = description;
	this.price = price;
	this.isAvailable = isAvailable;
	this.imgpath = imgpath;
}
public int getMenuid() {
	return menuid;
}
public void setMenuid(int menuid) {
	this.menuid = menuid;
}
public int getRestaurantid() {
	return restaurantid;
}
public void setRestaurantid(int restaruantid) {
	this.restaurantid = restaruantid;
}
public String getMenuname() {
	return menuname;
}
public void setMenuname(String menuname) {
	this.menuname = menuname;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
public double getPrice() {
	return price;
}
public void setPrice(double price) {
	this.price = price;
}
public boolean isAvailable() {
	return isAvailable;
}
public void setAvailable(boolean isAvailable) {
	this.isAvailable = isAvailable;
}
public String getImgpath() {
	return imgpath;
}
public void setImgpath(String imgpath) {
	this.imgpath = imgpath;
}
@Override
public String toString() {
	return "menu [menuid=" + menuid + ", restaurantid=" + restaurantid + ", menuname=" + menuname + ", description="
			+ description + ", price=" + price + ", isAvailable=" + isAvailable + ", imgpath=" + imgpath + "]";
}
   
   
   
}
