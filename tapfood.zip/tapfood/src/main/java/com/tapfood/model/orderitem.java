package com.tapfood.model;

public class orderitem {
	private int orderitenid;
	private int orderid;
	private int menuid;
	private int quantity;
	private double subtotal;
	public orderitem() {
		super();
	}
	public orderitem(int orderitenid, int orderid, int menuid, int quantity, double subtotal) {
		super();
		this.orderitenid = orderitenid;
		this.orderid = orderid;
		this.menuid = menuid;
		this.quantity = quantity;
		this.subtotal = subtotal;
	}
	public orderitem(int orderid, int menuid, int quantity, double subtotal) {
		super();
		this.orderid = orderid;
		this.menuid = menuid;
		this.quantity = quantity;
		this.subtotal = subtotal;
	}
	public int getOrderitenid() {
		return orderitenid;
	}
	public void setOrderitenid(int orderitenid) {
		this.orderitenid = orderitenid;
	}
	public int getOrderid() {
		return orderid;
	}
	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}
	public int getMenuid() {
		return menuid;
	}
	public void setMenuid(int menuid) {
		this.menuid = menuid;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getSubtotal() {
		return subtotal;
	}
	public void setSubtotal(double subtotal) {
		this.subtotal = subtotal;
	}
	@Override
	public String toString() {
		return "orderitem [orderitenid=" + orderitenid + ", orderid=" + orderid + ", menuid=" + menuid + ", quantity="
				+ quantity + ", subtotal=" + subtotal + "]";
	}
	
	

}
