package com.tapfood.model;
import java.sql.Date; 

public class ordertable {
    
    private int orderid;
    private int userid;
    private int restaurantid;
    private Date orderdate; // Ensure the correct date type is java.sql.Date
    private double totalamount;
    private String paymentmode;
    private String status;
    
    // Constructor with all fields
    public ordertable(int orderid, int userid, int restaurantid, Date orderdate, double totalamount, String status, String paymentmode) {
        this.orderid = orderid;
        this.userid = userid;
        this.restaurantid = restaurantid;
        this.orderdate = orderdate;
        this.totalamount = totalamount;
        this.status = status;
        this.paymentmode = paymentmode;
    }

    // Constructor without order ID (for inserting a new order)
    public ordertable(int userid, int restaurantid, Date orderdate, int totalamount, String paymentmode, String status) {
        this.userid = userid;
        this.restaurantid = restaurantid;
        this.orderdate = orderdate;
        this.totalamount = totalamount;
        this.paymentmode = paymentmode;
        this.status = status;
    }

    

	// Getters and Setters
    public int getOrderid() {
        return orderid;
    }

    public void setOrderid(int orderid) {
        this.orderid = orderid;
    }

    public int getUserid() {
        return userid;
    }

    public void setUserid(int userid) {
        this.userid = userid;
    }

    public int getRestaurantid() {
        return restaurantid;
    }

    public void setRestaurantid(int restaurantid) {
        this.restaurantid = restaurantid;
    }

    public Date getOrderdate() {
        return orderdate;
    }

    public void setOrderdate(Date orderdate) {
        this.orderdate = orderdate;
    }

    public double getTotalamount() {
        return totalamount;
    }

    public void setTotalamount(int totalamount) {
        this.totalamount = totalamount;
    }

    public String getPaymentmode() {
        return paymentmode;
    }

    public void setPaymentmode(String paymentmode) {
        this.paymentmode = paymentmode;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "ordertable [orderid=" + orderid + ", userid=" + userid + ", restaurantid=" + restaurantid
                + ", orderdate=" + orderdate + ", totalamount=" + totalamount + ", status=" + status + ", paymentmode=" + paymentmode + "]";
    }
}
