<%@ page import="com.tapfood.model.cart" %>
<%@ page import="com.tapfood.model.cartItem" %>
<%@ page session="true" contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Your Cart</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 20px;
        }
        .container {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }
        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 12px;
            text-align: center;
        }
        th {
            background-color: #f4f4f4;
            color: #555;
        }
        .total {
            font-weight: bold;
            background-color: #f4f4f4;
        }
        .actions {
            display: flex;
            justify-content: center;
            gap: 10px;
        }
        .actions form {
            margin: 0;
        }
        .btn, .remove-btn {
            padding: 10px 15px;
            border: none;
            color: #fff;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }
        .btn {
            background-color: #4CAF50;
        }
        .btn:hover {
            background-color: #45a049;
        }
        .remove-btn {
            background-color: #f44336;
        }
        .remove-btn:hover {
            background-color: #d32f2f;
        }
        .quantity-controls {
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .quantity-controls button {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .quantity-controls button:hover {
            background-color: #45a049;
        }
        .quantity-controls input[type="text"] {
            width: 40px;
            text-align: center;
            border: 1px solid #ccc;
            border-radius: 4px;
            margin: 0 5px;
        }
        .price-column {
            text-align: right;
        }

        /* Style for the Menu button */
        .menu-btn {
            background-color: #2196F3;
            padding: 10px 20px;
            color: white;
            border-radius: 5px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
        }
        .menu-btn:hover {
            background-color: #1976D2;
        }
    </style>
    <script>
        function updateQuantity(itemId, quantity) {
            const xhr = new XMLHttpRequest();
            xhr.open("POST", "cart", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    location.reload();
                }
            };
            xhr.send("action=update&itemid=" + itemId + "&quantity=" + quantity);
        }

        function increaseQuantity(itemId) {
            const quantityInput = document.getElementById('quantity-' + itemId);
            let currentQuantity = parseInt(quantityInput.value);
            quantityInput.value = currentQuantity + 1;
            updateQuantity(itemId, currentQuantity + 1);
        }

        function decreaseQuantity(itemId) {
            const quantityInput = document.getElementById('quantity-' + itemId);
            let currentQuantity = parseInt(quantityInput.value);
            if (currentQuantity > 1) {
                quantityInput.value = currentQuantity - 1;
                updateQuantity(itemId, currentQuantity - 1);
            }
        }
    </script>
</head>
<body>
    <div class="container">
        <h1>Your Shopping Cart</h1>

        <%
            cart cart = (cart) session.getAttribute("cart");
            if (cart == null || cart.getItem().isEmpty()) {
        %>
        <p style="text-align: center;">Your cart is empty.</p>
        <%
            } else {
        %>
        <table>
            <tr>
                <th>Item</th>
                <th>Restaurant</th>
                <th>Price (₹)</th>
                <th>Quantity</th>
                <th>Subtotal (₹)</th>
                <th>Action</th>
            </tr>

            <%
                double total = 0;
                for (cartItem item : cart.getItem().values()) {
                    total += item.getQuantity() * item.getPrice();
            %>
            <tr>
                <td><%= item.getName() %></td>
                <td><%= item.getRestaurantid() %></td>
                <td class="price-column">₹<%= item.getPrice() %></td>
                <td>
                    <div class="quantity-controls">
                        <button type="button" onclick="decreaseQuantity(<%= item.getItemid() %>)">-</button>
                        <input type="text" id="quantity-<%= item.getItemid() %>" name="quantity" value="<%= item.getQuantity() %>" readonly>
                        <button type="button" onclick="increaseQuantity(<%= item.getItemid() %>)">+</button>
                    </div>
                </td>
                <td class="price-column">₹<%= item.getQuantity() * item.getPrice() %></td>
                <td>
                    <form action="cart" method="post" style="margin: 0;">
                        <input type="hidden" name="action" value="remove">
                        <input type="hidden" name="itemid" value="<%= item.getItemid() %>">
                        <input type="submit" class="btn remove-btn" value="Remove">
                    </form>
                </td>
            </tr>
            <%
                }
            %>
            <tr class="total">
                <td colspan="4">Total</td>
                <td class="price-column">₹<%= total %></td>
                <td></td>
            </tr>
        </table>
        <div class="actions">
            <form action="checkout.jsp" method="get">
                <input type="submit" class="btn" value="Proceed to Checkout">
            </form>
            <form action="cart" method="post">
                <input type="hidden" name="action" value="clear">
                <input type="submit" class="btn remove-btn" value="Clear Cart">
            </form>
        </div>
        <%
            }
        %>
        <center>
            <a href="menu.jsp" class="menu-btn">Menu</a>
        </center>
    </div>
</body>
</html>
