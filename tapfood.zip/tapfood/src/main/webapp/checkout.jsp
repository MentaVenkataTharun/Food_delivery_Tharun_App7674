<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.Map" %>
<%@ page import="com.tapfood.model.cartItem"%>
<%@ page import="com.tapfood.model.cart" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Checkout</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        h1 {
            color: #333;
        }
        .checkout-item {
            background-color: #fff;
            padding: 15px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .checkout-item strong {
            display: block;
            margin-bottom: 5px;
        }
        .total {
            margin-top: 20px;
            font-size: 1.2em;
            font-weight: bold;
            color: #333;
        }
        .payment-method {
            margin-top: 20px;
            padding: 15px;
            background-color: #fff;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .payment-method label {
            display: block;
            margin-bottom: 5px;
        }
          .address {
            margin-top: 20px;
            padding: 15px;
            background-color: #fff;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .address label {
            display: block;
            margin-bottom: 5px;
        }
        .address input[type="text"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 1em;
            box-sizing: border-box;
        }
        .checkout-form input[type="submit"] {
            background-color: #5cb85c;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1em;
        }
        .checkout-form input[type="submit"]:hover {
            background-color: #4cae4c;
        }
    </style>
</head>
<body>
    <h1>Checkout</h1>
    <%
  
        cart cart = (cart) session.getAttribute("cart");
        if (cart == null || cart.getItem().isEmpty()) {
            out.println("<h2>Your Cart is Empty!</h2>");
        } else {
            Map<Integer, cartItem> cartItems = cart.getItem();
            double total = 0.0;
            for (cartItem item : cartItems.values()) {
                total += item.getQuantity() * item.getPrice();
    %>
        <div class="checkout-item">
            <strong>Item ID:</strong> <%= item.getItemid() %>
            <strong>Name:</strong> <%= item.getName() %>
            <strong>Quantity:</strong> <%= item.getQuantity() %>
            <strong>Subtotal:</strong> $<%= String.format("%.2f", item.getSubtotal()) %>
        </div>
    <%
            }
    %>
    <div class="total">
        Total: $<%= String.format("%.2f", total) %>
    </div>
     </div>
    <div class="payment-method">
        <form class="checkout-form" action="orderConfirmation" method="post">
         <input type="hidden" name="total" value="<%= total %>">
         
    <div class ="address">
     <label for="address">Address:</label><input type="text" name="address">
    </div>
    
            <label for="payment">Choose Payment Method:</label>
            <select name="paymentMode" id="payment">
                <option value="creditCard">Credit Card</option>
                <option value="debitCard">Debit Card</option>
                <option value="paypal">PayPal</option>
                <option value="cashOnDelivery">Cash on Delivery</option>
            </select>
            <br><br>
            <input type="submit" value="Place Order">
        </form>
  
    <%
        }
    %>
</body>
</html>