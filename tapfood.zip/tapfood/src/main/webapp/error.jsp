<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Error</title>
</head>
<body>
    <h1>Error Occurred</h1>
    <p>
        <% 
            String error = request.getParameter("error");
            if (error != null) {
                switch (error) {
                    case "invalid_total":
                        out.println("The total amount is invalid. Please try again.");
                        break;
                    case "invalid_total_format":
                        out.println("The total amount format is incorrect. Please enter a valid number.");
                        break;
                    case "session_expired":
                        out.println("Session has expired. Please log in again.");
                        out.println("<br><a href='login.jsp'>Log In</a>");
                        break;
                    case "order_failed":
                        out.println("Failed to place the order. Please try again later.");
                        break;
                    case "exception":
                        out.println("An unexpected error occurred. Please try again later.");
                        break;
                    default:
                        out.println("An unknown error occurred. Please contact support.");
                        break;
                }
            } else {
                out.println("An unexpected error occurred. Please contact support.");
            }
        %>
    </p>
    <a href="index.jsp">Go back to the homepage</a>
</body>
</html>
