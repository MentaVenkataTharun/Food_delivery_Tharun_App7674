<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
</head>
<body>
	<center>
		<h1>Login Failed</h1>
		<p>Invalid email or password. Please try again.</p>
		<a href="login.jsp">Go back to Login</a>
	</center>
</body>
</html>