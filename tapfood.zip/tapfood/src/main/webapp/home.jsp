<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<%@ page
    import="com.tapfood.model.user,com.tapfood.model.Restaurant,java.util.List"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Tap Online Food Delivery</title>
<style>
   /* General styles */
body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #f9fafc;
    margin: 0;
    padding: 0;
    color: #2c3e50;
}

header {
    background-color: #34495e;
    color: #ecf0f1;
    padding: 20px 30px;
    text-align: center;
}

header h1 {
    margin: 0;
    font-size: 2.5em;
}

nav {
    margin-top: 10px;
}

nav a {
    color: #ecf0f1;
    text-decoration: none;
    margin: 0 15px;
    font-weight: bold;
    transition: color 0.3s ease;
}

nav a:hover {
    color: #f39c12;
}

h2 {
    text-align: center;
    margin: 20px 0;
    color: #2980b9;
}

.restaurant-list, .restaurant-container {
    padding: 20px;
}

/* Restaurant list styles */
.restaurant {
    background: #fff;
    border: 1px solid #e0e0e0;
    border-radius: 12px;
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
    margin: 20px;
    padding: 20px;
    width: calc(33% - 40px);
    box-sizing: border-box;
    text-align: center;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.restaurant:hover {
    transform: translateY(-8px);
    box-shadow: 0 10px 24px rgba(0, 0, 0, 0.15);
}

.restaurant h3 {
    margin-top: 0;
    color: #e74c3c;
}

.restaurant p {
    margin: 10px 0;
    color: #7f8c8d;
}

.restaurant a {
    display: inline-block;
    margin-top: 10px;
    padding: 12px 25px;
    text-decoration: none;
    color: #fff;
    background-color: #e74c3c;
    border-radius: 8px;
    transition: background-color 0.3s ease, box-shadow 0.3s ease;
}

.restaurant a:hover {
    background-color: #c0392b;
    box-shadow: 0 6px 15px rgba(231, 76, 60, 0.4);
}

@media (max-width: 768px) {
    .restaurant {
        width: calc(50% - 40px);
    }
}

@media (max-width: 480px) {
    .restaurant {
        width: calc(100% - 40px);
    }
}

/* Restaurant container styles */
.restaurant-container {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    background-color: #ecf0f1;
    padding: 40px 20px;
}

.restaurant-box {
    background: #fff;
    border: 1px solid #e0e0e0;
    border-radius: 12px;
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
    margin: 20px;
    padding: 30px 20px;
    width: calc(25% - 40px);
    box-sizing: border-box;
    text-align: center;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.restaurant-box:hover {
    transform: translateY(-8px);
    box-shadow: 0 10px 24px rgba(0, 0, 0, 0.15);
}

.restaurant-box img {
    max-width: 100%;
    border-radius: 8px;
}

.restaurant-box h1 {
    margin-top: 15px;
    font-size: 1.8em;
    color: #e74c3c;
}

.restaurant-box p {
    margin: 15px 0;
    font-size: 1.2em;
    color: #7f8c8d;
}

.restaurant-box a {
    display: inline-block;
    margin-top: 20px;
    padding: 12px 25px;
    text-decoration: none;
    color: #fff;
    background-color: #2980b9;
    border-radius: 8px;
    transition: background-color 0.3s ease, box-shadow 0.3s ease;
}

.restaurant-box a:hover {
    background-color: #1f669f;
    box-shadow: 0 6px 15px rgba(41, 128, 185, 0.4);
}

@media (max-width: 768px) {
    .restaurant-box {
        width: calc(50% - 30px);
    }
}

@media (max-width: 480px) {
    .restaurant-box {
        width: calc(100% - 30px);
    }
}

</style>
</head>
<body>
    <header>
        <h1>Welcome to Online Food Delivery</h1>
        <nav>
            <%
            user loggedInUser = (user) session.getAttribute("loggedInUser");
            if (loggedInUser != null) {
            %>
            <span>Welcome, <%= loggedInUser.getUsername() %></span>
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">
                    <a class="navbar-brand" href="#"></a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                        <div class="navbar-nav">
                            <a class="nav-link active" aria-current="page" href="Home">Home</a>
                            <a class="nav-link" href="cart">View Cart</a>
                            <a class="nav-link" href="orderHistory">Order History</a>
                            <a class="nav-link" href="logout">Logout</a>
                        </div>
                    </div>
                </div>
            </nav>
            <%
            } else {
            %>
            <a href="login.jsp">Login</a> 
            <a href="register.jsp">Register</a>
            <%
            }
            %>
        </nav>
    </header>

    <h2>Featured Restaurants</h2>
    <section class="restaurant-list">
        <%
        List<Restaurant> restaurantList = (List<Restaurant>) session.getAttribute("restaurantsList");
        if (restaurantList != null) {
            for (Restaurant restaurant : restaurantList) {
        %>
        <div class="restaurant">
            <h3><%= restaurant.getRestaurantname() %></h3>
            <p>Delivery Time: <%= restaurant.getDeliverytime() %> minutes</p>
            <p>Cuisine Type: <%= restaurant.getCuisinetype() %></p>
            <p>Rating: <%= restaurant.getRating() %> ★</p>
            <a href="menu?restaurantid=<%= restaurant.getRestaurantid() %>">View Menu</a>
        </div>
        <%
            }
        } else {
        %>
        <p>No restaurants available.</p>
        <%
        }
        %>
    </section>

    <div class="restaurant-container">
        <div class="restaurant-box">
            <img src="https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.fontinlogo.com%2Flogo%2Fdominos-pizza&psig=AOvVaw1gNPdgHyZfP5a9PaQITo65&ust=1726051550556000&source=images&cd=vfe&opi=89978449&ved=2ahUKEwi3ocadmbiIAxWna2wGHRkJHe8QjRx6BAgAEBg" alt="Starbucks">
            <h1>Starbucks</h1>
            <p>Cold Coffee - 30 mins</p>
            <a href="menu?restaurantid=1">View Menu</a>
        </div>
        <div class="restaurant-box">
            <img src="https://example.com/pizzahut-image.jpg" alt="Pizza Hut">
            <h1>Pizza Hut</h1>
            <p>Corn Pizza - 20 mins</p>
            <a href="menu?restaurantid=2">View Menu</a>
        </div>
        <div class="restaurant-box">
            <img src="https://example.com/ghar-ka-khana-image.jpg" alt="Ghar Ka Khana">
            <h1>Ghar Ka Khana</h1>
            <p>Roti, Paneer Butter Masala - 25 mins</p>
            <a href="menu?restaurantid=3">View Menu</a>
        </div>
        <div class="restaurant-box">
            <img src="https://example.com/dominos-image.jpg" alt="Dominos">
            <h1>Dominos</h1>
            <p>Veg Burger - 40 mins</p>
            <a href="menu?restaurantid=4">View Menu</a>
        </div>
    </div>
</body>
</html>
