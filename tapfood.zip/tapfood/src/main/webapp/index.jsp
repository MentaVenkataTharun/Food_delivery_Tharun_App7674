<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
	pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
</head>


<style>
body {
    font-family: 'Roboto', sans-serif;
    background: #f4f4f4; /* Light grey background for the page */
    margin: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

.container {
    width: 90%; /* Responsive width */
    max-width: 600px; /* Maximum width for larger screens */
    background: #fff; /* White background for the container */
    padding: 30px;
    border-radius: 12px;
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
    text-align: center;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
}

.container h1 {
    margin-bottom: 25px;
    color: #333; /* Dark text color for contrast */
    font-size: 28px;
    font-weight: 600;
}

.container a {
    display: block;
    margin: 15px 0;
    padding: 15px 30px;
    text-decoration: none;
    color: #fff;
    background-color: #28a745; /* Green button color */
    border-radius: 8px;
    font-weight: bold;
    font-size: 18px;
    transition: background-color 0.3s ease, transform 0.3s ease;
}

.container a:hover {
    background-color: #218838; /* Darker green on hover */
    transform: translateY(-2px); /* Slight lift effect */
}

.container a:active {
    background-color: #1e7e34; /* Even darker green when clicked */
    transform: translateY(0); /* Reset lift effect */
}


</style>

</head>
<body>
	<div class="container">
		<h1>Welcome</h1>
		<a href="signUp.jsp">Sign Up</a> <a href="login.jsp">Login</a>
	</div>
</body>
</html>


