<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title></title>
</head>
<body>
 <center>
      <h1>Login page</h1>
      <table>
            <form  action="login" method="post">
                 <tr>
                 <td><label>Email</label></td>
                 <td><input type="email" name="email"></td>
                 </tr>
            
            <tr>
            <td><label>password</label></td>
            <td><input type="password" name="password"></td>
            </tr>
            <tr>
            <td></td>
            <td><input type="submit" value="Login"></td>
            </tr>
            
            </form>
      
      
      </table>
 
 </center>
</body>
</html>

<style>

body {
    font-family: 'Roboto', sans-serif;
    background-color: #111;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
    color: #f1f1f1;
}

form {
    width: 100%;
    max-width: 400px;
    background-color: #222;
    padding: 40px;
    border-radius: 10px;
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.5);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

form:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.7);
}

h1 {
    text-align: center;
    color: #fff;
    font-size: 28px;
    margin-bottom: 30px;
    font-weight: 500;
    letter-spacing: 1px;
}

/* Label styling */
label {
    display: block;
    color: #ddd;
    margin-bottom: 8px;
    font-weight: 500;
}

/* Input field styling */
input[type="email"],
input[type="password"] {
    width: 100%;
    padding: 12px 15px;
    margin-bottom: 20px;
    border: 1px solid #444;
    background-color: #333;
    color: #fff;
    border-radius: 6px;
    transition: border-color 0.3s ease, box-shadow 0.3s ease;
}

/* Focus state */
input[type="email"]:focus,
input[type="password"]:focus {
    border-color: #ff7e5f;
    box-shadow: 0 0 8px rgba(255, 126, 95, 0.5);
    outline: none;
}

/* Submit button styling */
input[type="submit"] {
    width: 100%;
    padding: 14px;
    background-color: #ff7e5f;
    color: white;
    font-size: 16px;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

input[type="submit"]:hover {
    background-color: #e76e55;
}

/* For smaller screens */
@media (max-width: 600px) {
    form {
        width: 90%;
        padding: 30px;
    }

    h1 {
        font-size: 24px;
    }

    input[type="submit"] {
        padding: 12px;
    }
}
</style>