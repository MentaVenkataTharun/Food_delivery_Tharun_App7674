<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.ArrayList" %>
<%@ page import="com.tapfood.model.menu" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Menu</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f2f5;
            margin: 0;
            padding: 20px;
            color: #333;
        }

        h1 {
            text-align: center;
            color: #444;
            margin-bottom: 30px;
        }

        .menu-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
        }

        .menu-item {
            border: 1px solid #ddd;
            padding: 20px;
            border-radius: 10px;
            background-color: #ffffff;
            max-width: 300px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
        }

        .menu-item:hover {
            transform: scale(1.02);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
        }

        .menu-item img {
            width: 100%;
            height: auto;
            border-radius: 10px;
            object-fit: cover;
            margin-bottom: 15px;
        }

        .menu-details {
            text-align: center;
        }

        .menu-name {
            font-size: 22px;
            font-weight: bold;
            color: #222;
            margin-bottom: 10px;
        }

        .menu-description {
            font-size: 14px;
            color: #555;
            margin-bottom: 10px;
        }

        .menu-price {
            font-size: 18px;
            color: #27ae60;
            font-weight: bold;
            margin-bottom: 15px;
        }

        form {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 10px;
        }

        input[type="number"] {
            width: 80px;
            padding: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        input[type="submit"] {
            padding: 10px 20px;
            border: none;
            background-color: #27ae60;
            color: #ffffff;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.2s ease-in-out;
        }

        input[type="submit"]:hover {
            background-color: #218c53;
        }
    </style>
</head>
<body>
    <h1>Menu</h1>
    <div class="menu-container">
        <%
            ArrayList<menu> menuList = (ArrayList)session.getAttribute("menulist");
            if (menuList != null && !menuList.isEmpty()) {
                for (menu menu : menuList) {
        %>
        <div class="menu-item">
            <%-- Add an image if available --%>
            <% if (menu.getImgpath() != null && !menu.getImgpath().isEmpty()) { %>
                <img src="<%= menu.getImgpath() %>" alt="<%= menu.getMenuname() %>">
            <% } %>
            <div class="menu-details">
                <div class="menu-name"><%= menu.getMenuname() %></div>
                <div class="menu-description"><%= menu.getDescription() %></div>
                <div class="menu-price">₹<%= menu.getPrice() %></div>
                <form action="cart" method="post">
                    <input type="hidden" name="itemid" value="<%= menu.getMenuid() %>">
                    Quantity: <input type="number" name="quantity" value="1" min="1">
                    <input type="hidden" name="action" value="add">
                    <input type="submit" value="Add to Cart">
                </form>
            </div>
        </div>
        <%
                }
            } else {
        %>
        <p>No menu items available.</p>
        <%
            }
        %>
    </div>
</body>
</html>
