<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Order Confirmation</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f9;
        margin: 0;
        padding: 0;
        color: #333;
    }

    .confirmation-container {
        max-width: 600px;
        margin: 50px auto;
        background-color: #fff;
        padding: 30px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        border-radius: 10px;
        text-align: center;
    }

    h2 {
        color: #27ae60;
        font-size: 2em;
        margin-bottom: 20px;
    }

    p {
        font-size: 1.2em;
        margin-bottom: 20px;
    }

    .order-summary {
        text-align: left;
        margin: 20px 0;
    }

    .order-summary h3 {
        color: #555;
        margin-bottom: 10px;
    }

    .order-summary p {
        margin: 5px 0;
    }

    a {
        display: inline-block;
        margin-top: 20px;
        padding: 10px 20px;
        background-color: #27ae60;
        color: white;
        text-decoration: none;
        border-radius: 5px;
        transition: background-color 0.3s ease;
    }

    a:hover {
        background-color: #218c53;
    }
</style>
</head>
<body>
    <div class="confirmation-container">
        <h2>Thank You for Your Order!</h2>
        <p>Your order has been successfully placed. We will deliver your food shortly!</p>
        
        <div class="order-summary">
            <h3>Order Summary:</h3>
            <p>Name: <%= session.getAttribute("orderName") %></p>
            <p>Email: <%= session.getAttribute("orderEmail") %></p>
            <p>Delivery Address: <%= session.getAttribute("orderAddress") %></p>
            <p>Phone: <%= session.getAttribute("orderPhone") %></p>
            <p>Total Amount: <%= session.getAttribute("totalAmount") %></p>
        </div>

        <a href="home.jsp">Back to Home</a>
    </div>
</body>
</html>
