<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Sign Up</title>
    <link rel="stylesheet" type="text/css" href="css/styles.css">
</head>
<body>
    <div class="signup-container">
        <h1>Sign Up</h1>
        <form action="signup" method="post">
            <%
                String errorMessage = (String) request.getAttribute("errorMessage");
                if (errorMessage != null) {
            %>
                <div class="error-message"><%= errorMessage %></div>
            <%
                }
            %>
            <div class="form-group">
                <label for="username">Name</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="form-group">
                <label for="phonenumber">Phone Number</label>
                <input type="text" id="phonenumber" name="phonenumber" required>
            </div>
            <div class="form-group">
                <label for="address">Address</label>
                <input type="text" id="address" name="address" required>
            </div>
            <div class="form-group">
                <input type="submit" value="Register">
            </div>
        </form>
    </div>
</body>
</html>

<style>

/* General Reset */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Roboto', sans-serif;
    background: #111;
    color: #f1f1f1;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

/* Sign-up container */
.signup-container {
    background-color: #222;
    border-radius: 12px;
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.5);
    width: 100%;
    max-width: 400px;
    padding: 40px;
    text-align: center;
    transition: all 0.3s ease;
}

.signup-container:hover {
    transform: translateY(-10px);
    box-shadow: 0 12px 25px rgba(0, 0, 0, 0.7);
}

/* Title */
h1 {
    color: #f1f1f1;
    font-size: 30px;
    margin-bottom: 25px;
    font-weight: 500;
    letter-spacing: 1px;
}

/* Form group styling */
.form-group {
    margin-bottom: 20px;
    text-align: left;
}

/* Label styling */
label {
    font-size: 15px;
    color: #ddd;
    margin-bottom: 6px;
    display: block;
    font-weight: 500;
}

/* Input fields styling */
input[type="text"],
input[type="email"],
input[type="password"] {
    width: 100%;
    padding: 12px 15px;
    border: 1px solid #444;
    background-color: #333;
    color: #f1f1f1;
    border-radius: 8px;
    font-size: 14px;
    transition: border-color 0.3s ease, box-shadow 0.3s ease;
}

/* Focus state */
input:focus {
    border-color: #ff7e5f;
    box-shadow: 0 0 8px rgba(255, 126, 95, 0.4);
    outline: none;
}

/* Submit button */
input[type="submit"] {
    width: 100%;
    padding: 14px;
    background-color: #ff7e5f;
    color: white;
    font-size: 16px;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

input[type="submit"]:hover {
    background-color: #e76e55;
}

/* Error message */
.error-message {
    color: #e74c3c;
    margin-bottom: 15px;
    text-align: left;
    font-weight: 500;
}

/* For smaller screens */
@media (max-width: 600px) {
    .signup-container {
        width: 90%;
        padding: 30px;
    }

    h1 {
        font-size: 26px;
    }

    input[type="submit"] {
        padding: 12px;
    }
}

</style>
